chmod +x ./3D_Filter_GUI
spctl --add ./3D_Filter_GUI
chmod +x ./3D_Filter_GUI

